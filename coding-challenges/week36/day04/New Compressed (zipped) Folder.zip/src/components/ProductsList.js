import React from 'react'

function ProductsList(props) {
    return (
         <div className='border'>
            {props.username}
        </div>
    )
}

export { ProductsList }