import React from 'react'

function UsersList(props) {
    return (
        <div className='border'>
            {props.username}
        </div>
    )
}

export {UsersList}
