import { Transaction_Page } from "./componenets/Transaction_Page";

function App() {
  return (
    <Transaction_Page/>    
  );
}

export default App;
