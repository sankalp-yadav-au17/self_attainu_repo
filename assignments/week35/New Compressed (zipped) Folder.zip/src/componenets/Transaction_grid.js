import React from 'react'
import { useContext, useState, useEffect } from 'react'
import {contextName} from "./Transaction_Page" 

function Transaction_grid() {
    const [balance, setbalance] = useState(0)
    const context = useContext(contextName)
    
    useEffect(()=>{
      if (context != null && context[0].Card ==="Credit"){
        const sum = balance + context[0].Amt
        console.log(sum);
      return setbalance(sum)
    }
    else if (context != null && context[0].Card ==="Debit"){
      const sum = balance - context[0].Amt
      return setbalance(sum)
    }
  },[])

    return (
        <div>
            <table class="table">
  <thead>
    <tr>
      <th scope="col">Date</th>
      <th scope="col">Description</th>
      <th scope="col">Credit</th>
      <th scope="col">Debit</th>
      <th scope="col">Running Bal.</th>

    </tr>
  </thead>
  <tbody>
  {context.map((data)=>{
              return <tr>
                <td scope="row">{data.Date}/{data.Month}/{data.Year}</td>
                <td>{data.Descrip}</td>
                <td>{data.Card === "Credit" ? data.Amt : null }</td>
                <td>{data.Card === "Credit" ? null : data.Amt}</td>
                <td>Rs. {balance} </td>
            </tr> 
            })}

  </tbody>
</table>
        </div>
    )
}

export  {Transaction_grid}


